﻿Imports System.Data.OleDb
Public Class ClsDBConnector
    Dim con As New OleDbConnection
    Dim dbProvider As String
    Dim dbSource As String
    Dim da As OleDb.OleDbDataAdapter
    Dim ds As New DataSet
    Sub connect(x)
        Dim FilePath = DatabaseSauce(x)
        If My.Computer.FileSystem.FileExists(FilePath) Then
            dbProvider = "PROVIDER=Microsoft.ACE.OLEDB.12.0;"
            dbSource = "Data Source = " & DatabaseSauce(x)
            con.ConnectionString = dbProvider & dbSource
            Console.WriteLine("Connected to local database.")
        Else
            con.ConnectionString = "Provider=SQLOLEDB; " &
                              "Server=tcp:portway-db.database.windows.net,1433; " &
                              "Database=portway-db; " &
                              "Uid=alexh@portway-db; " &
                              "Pwd=Warhammer40k;"
            Console.WriteLine("Connected to remote database.")
        End If

        con.Open()
    End Sub
    Function DatabaseSauce(x As String)

        Dim filePath As String = ""                                     'declares an empty string variable to store the filepath of the database used by the program.
        filePath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase)
        filePath = filePath.Remove(0, 6)
        If x = "Login" Then
            filePath += "\StaffLogin.accdb"
        ElseIf x = "Main" Then
            filePath += "\PortwayDatabase.accdb"
        End If

        'MsgBox(filePath)
        Return filePath
    End Function
    Sub close()
        con.Close()
        'closes connection to database and states so to the user
    End Sub
    Function sqlSelect(ByVal sqlString As String)
        da = New OleDbDataAdapter(sqlString, con)
        'create a new data-adapter object & tell it to use the SQL statement and connection info provided.

        ds.Clear() 'wipes the data-set clean

        da.Fill(ds, "Results")
        'executes the SQL query and fills the dataset "Results" with the data

        Return ds 'sends the data back to the calling code
    End Function
End Class
