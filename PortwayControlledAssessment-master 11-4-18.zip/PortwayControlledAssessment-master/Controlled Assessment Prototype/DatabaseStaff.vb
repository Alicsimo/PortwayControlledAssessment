﻿Public Class DatabaseStaff
    Dim db As New ClsDBConnector
    Dim ds As New DataSet

    Private Sub btnLogout_Click(sender As Object, e As EventArgs) Handles btnLogout.Click
        LoginForm.Show()
        Me.Close()
    End Sub

    Private Sub btnAdmin_Click(sender As Object, e As EventArgs) Handles btnAdmin.Click
        AdminConsole.Show()
        Me.Close()
    End Sub

    Private Sub DatabaseStaff_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim sql As String

        db.connect("Main")
        sql = "SELECT * FROM tblMembers" ' WHERE MemberName LIKE '%" & txbName.Text & "%'"
        ds = db.sqlSelect(sql)

        Dim recordCount As Integer = 0
        Dim xCounter As Integer = 0
        recordCount = ds.Tables("Results").Rows.Count   'Counts the number of records
        lsvStaff.Items.Clear()                          'Clears list view
        Do Until xCounter = recordCount                 'Adds all records available based on given query
            lsvStaff.Items.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(1))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(2))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(3))
            'lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(4))
            'lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(5))
            'lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(6))
            'lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            xCounter = xCounter + 1
        Loop
        db.close()
        lsvStaff.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
        lsvStaff.AutoResizeColumn(1, ColumnHeaderAutoResizeStyle.HeaderSize)
    End Sub

    Private Sub btnRefresh_Click(sender As Object, e As EventArgs) Handles btnRefresh.Click
        Dim sql As String

        db.connect("Main")
        sql = "SELECT * FROM tblMembers" ' WHERE MemberName LIKE '%" & txbName.Text & "%'"
        ds = db.sqlSelect(Sql)

        Dim recordCount As Integer = 0
        Dim xCounter As Integer = 0
        recordCount = ds.Tables("Results").Rows.Count   'Counts the number of records
        lsvStaff.Items.Clear()                          'Clears list view
        Do Until xCounter = recordCount                 'Adds all records available based on given query
            lsvStaff.Items.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(1))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(2))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(3))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(4))
            'lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(5))
            'lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(6))
            'lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            xCounter = xCounter + 1
        Loop
        db.close()
        lsvStaff.AutoResizeColumns(ColumnHeaderAutoResizeStyle.ColumnContent)
    End Sub

    Private Sub btnSearchName_Click(sender As Object, e As EventArgs) Handles btnSearchName.Click
        Dim sql As String
        sql = "SELECT * FROM tblMembers WHERE MemberName LIKE '%" & txtName.Text & "%'"


        db.connect("Main")

        ds = db.sqlSelect(sql)
        'sends the above sql statement into the sqlSelect funtion inside the DBConnector Class

        'MsgBox(ds.Tables("Results").Rows.Count())
        'shows the number of rows of data returned

        Dim recordCount As Integer = 0
        Dim xCounter As Integer = 0
        recordCount = ds.Tables("Results").Rows.Count   'Counts the number of records
        lsvStaff.Items.Clear()                          'Clears list view
        Do Until xCounter = recordCount                 'Adds all records available based on given query
            lsvStaff.Items.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(1))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(2))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(3))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(4))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(5))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(6))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            xCounter = xCounter + 1
        Loop

        db.close()
    End Sub

    Private Sub btnSearchAge_Click(sender As Object, e As EventArgs) Handles btnSearchAge.Click
        Dim sql As String
        sql = "SELECT * FROM tblMembers WHERE MemberAge LIKE '%" & txtAge.Text & "%'"


        db.connect("Main")

        ds = db.sqlSelect(sql)
        'sends the above sql statement into the sqlSelect funtion inside the DBConnector Class

        'MsgBox(ds.Tables("Results").Rows.Count())
        'shows the number of rows of data returned

        Dim recordCount As Integer = 0
        Dim xCounter As Integer = 0
        recordCount = ds.Tables("Results").Rows.Count   'Counts the number of records
        lsvStaff.Items.Clear()                          'Clears list view
        Do Until xCounter = recordCount                 'Adds all records available based on given query
            lsvStaff.Items.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(1))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(2))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(3))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(4))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(5))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(6))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            xCounter = xCounter + 1
        Loop

        db.close()
    End Sub

    Private Sub btnSearchClub_Click(sender As Object, e As EventArgs) Handles btnSearchClub.Click
        Dim sql As String
        sql = "SELECT * FROM tblMembers WHERE MemberClub LIKE '%" & txtClub.Text & "%'"


        db.connect("Main")

        ds = db.sqlSelect(sql)
        'sends the above sql statement into the sqlSelect funtion inside the DBConnector Class

        'MsgBox(ds.Tables("Results").Rows.Count())
        'shows the number of rows of data returned

        Dim recordCount As Integer = 0
        Dim xCounter As Integer = 0
        recordCount = ds.Tables("Results").Rows.Count   'Counts the number of records
        lsvStaff.Items.Clear()                          'Clears list view
        Do Until xCounter = recordCount                 'Adds all records available based on given query
            lsvStaff.Items.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(1))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(2))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(3))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(4))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(5))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(6))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            xCounter = xCounter + 1
        Loop

        db.close()
    End Sub

    Private Sub btnSearchTime_Click(sender As Object, e As EventArgs) Handles btnSearchTime.Click
        Dim sql As String
        sql = "SELECT * FROM tblMembers WHERE MemberTime LIKE '%" & txtTime.Text & "%'"


        db.connect("Main")

        ds = db.sqlSelect(sql)
        'sends the above sql statement into the sqlSelect funtion inside the DBConnector Class

        'MsgBox(ds.Tables("Results").Rows.Count())
        'shows the number of rows of data returned

        Dim recordCount As Integer = 0
        Dim xCounter As Integer = 0
        recordCount = ds.Tables("Results").Rows.Count   'Counts the number of records
        lsvStaff.Items.Clear()                          'Clears list view
        Do Until xCounter = recordCount                 'Adds all records available based on given query
            lsvStaff.Items.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(1))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(2))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(3))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(4))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(5))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(6))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            xCounter = xCounter + 1
        Loop

        db.close()
    End Sub

    Private Sub btnSearchType_Click(sender As Object, e As EventArgs) Handles btnSearchType.Click
        Dim sql As String
        sql = "SELECT * FROM tblMembers WHERE MemberType LIKE '%" & txtType.Text & "%'"


        db.connect("Main")

        ds = db.sqlSelect(sql)
        'sends the above sql statement into the sqlSelect funtion inside the DBConnector Class

        'MsgBox(ds.Tables("Results").Rows.Count())
        'shows the number of rows of data returned

        Dim recordCount As Integer = 0
        Dim xCounter As Integer = 0
        recordCount = ds.Tables("Results").Rows.Count   'Counts the number of records
        lsvStaff.Items.Clear()                          'Clears list view
        Do Until xCounter = recordCount                 'Adds all records available based on given query
            lsvStaff.Items.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(1))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(2))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(3))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(4))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(5))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(6))
            lsvStaff.Items(xCounter).SubItems.Add(ds.Tables("Results").Rows(xCounter).Item(0))
            xCounter = xCounter + 1
        Loop

        db.close()
    End Sub
    '
    Private Sub GetFocusName(sender As Object, e As EventArgs) Handles txtName.GotFocus
        txtName.Text = ""
    End Sub
    Private Sub LoseFocusName(sender As Object, e As EventArgs) Handles txtName.LostFocus
        txtName.Text = "Name"
    End Sub
    '
    Private Sub GetFocusAge(sender As Object, e As EventArgs) Handles txtAge.GotFocus
        txtAge.Text = ""
    End Sub
    Private Sub LoseFocusAge(sender As Object, e As EventArgs) Handles txtAge.LostFocus
        txtAge.Text = "Age"
    End Sub
    '
    Private Sub GetFocusClub(sender As Object, e As EventArgs) Handles txtClub.GotFocus
        txtClub.Text = ""
    End Sub
    Private Sub LoseFocusClub(sender As Object, e As EventArgs) Handles txtClub.LostFocus
        txtClub.Text = "Club"
    End Sub
    '
    Private Sub GetFocusStroke(sender As Object, e As EventArgs) Handles txtStroke.GotFocus
        txtStroke.Text = ""
    End Sub
    Private Sub LoseFocusStroke(sender As Object, e As EventArgs) Handles txtStroke.LostFocus
        txtStroke.Text = "Stroke"
    End Sub
    '
    Private Sub GetFocusTime(sender As Object, e As EventArgs) Handles txtTime.GotFocus
        txtTime.Text = ""
    End Sub
    Private Sub LoseFocusTime(sender As Object, e As EventArgs) Handles txtTime.LostFocus
        txtTime.Text = "Time"
    End Sub
    '
    Private Sub GetFocusType(sender As Object, e As EventArgs) Handles txtType.GotFocus
        txtType.Text = ""
    End Sub
    Private Sub LoseFocusType(sender As Object, e As EventArgs) Handles txtType.LostFocus
        txtType.Text = "Type of Time"
    End Sub
    '
    Private Sub GetFocusGender(sender As Object, e As EventArgs) Handles txtGender.GotFocus
        txtGender.Text = ""
    End Sub
    Private Sub LoseFocusGender(sender As Object, e As EventArgs) Handles txtGender.LostFocus
        txtGender.Text = "Gender"
    End Sub
End Class